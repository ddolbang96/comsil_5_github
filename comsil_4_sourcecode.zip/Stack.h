#pragma once
#include "LinkedList.h"

//LinkedList class를 상속받음
template <class T>
class Stack : public LinkedList<T> {
public:
	bool Delete(int& element) { //Delete 함수 재정의
		//first가 0이면 false반환
		if (this->first == 0)
			return false;
		// LinkedList와 달리 Stack은 current가 가리키는 곳을 삭제
		Node<T>* current = this->first; //current에 first 노드 저장
		this->first = this->first->link; //first의 링크가 가리키는 곳을 first로 재지정. 리스트에서 첫번째 원소 삭제한 셈.
		current->link = 0; //current에 저장된 first노드의 링크를 0으로.
		element = current->data; //current에 저장된 first노드의 값을 따로 저장
		delete current; //current 삭제
		this->current_size--; //리스트 사이즈 1 줄임

		return true;
	}
};

